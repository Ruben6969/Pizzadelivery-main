# Another Spring Boot simple example

**About**: A coffee shop offers a limited number of beverages and wants a very simple application for the clients to set orders. A client will simply have to select the beverage from a list, get an order number, and then wait till his number is announced. Upon giving the beverage to the client, the cashier will mark the order as completed. 
Client do not need to login to set an order. 

