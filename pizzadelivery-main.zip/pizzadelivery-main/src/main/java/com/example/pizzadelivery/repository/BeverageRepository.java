package com.example.pizzadelivery.repository;

import com.example.pizzadelivery.model.Beverage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BeverageRepository extends JpaRepository<Beverage, Long> {
}
